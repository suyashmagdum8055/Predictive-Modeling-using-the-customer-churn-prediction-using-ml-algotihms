# Churn A1 Package

Production-ready churn modeling kit.

## Files
- `train_churn_pipeline.py` – trains a single joblib pipeline (preprocess + SMOTE + RandomForest with tuning) and saves `customer_churn_pipeline.pkl`.
- `app.py` – Streamlit app for single & batch predictions using the saved pipeline.

## How to Train
1. Put the Telco CSV in the same folder (default filename: `WA_Fn-UseC_-Telco-Customer-Churn (1).csv`).
2. Run:
   ```bash
   python train_churn_pipeline.py --csv "WA_Fn-UseC_-Telco-Customer-Churn (1).csv" --out customer_churn_pipeline.pkl
   ```

## How to Run App
```bash
streamlit run app.py
```
In the sidebar, keep the model path as `customer_churn_pipeline.pkl` (or update if you used a different name).

## Why this avoids UnpicklingError
- We save **one** self-contained scikit-learn/imbalanced-learn pipeline with **joblib**.
- All preprocessing (OneHotEncoder, imputers), SMOTE, and the model live inside the pipeline.
- No separate encoders to keep in sync.
