# train_churn_pipeline.py
# A1-class Telco Customer Churn training script.
# - Cleans data
# - ColumnTransformer (OHE for categoricals, impute numerics)
# - SMOTE for imbalance
# - RandomizedSearchCV over RandomForest
# - Saves a single self-contained pipeline with joblib

import argparse
import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold, RandomizedSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, recall_score, f1_score, roc_auc_score, classification_report, confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from scipy.stats import randint
import joblib

RANDOM_STATE = 42

SERVICE_NO_KEYS = [
    "MultipleLines", "OnlineSecurity", "OnlineBackup", "DeviceProtection",
    "TechSupport", "StreamingTV", "StreamingMovies"
]

def load_and_clean(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    # Drop id if present
    if "customerID" in df.columns:
        df = df.drop(columns=["customerID"])
    # Coerce TotalCharges
    if "TotalCharges" in df.columns:
        df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    # Simplify service 'No internet/phone service' => 'No'
    for col in SERVICE_NO_KEYS:
        if col in df.columns:
            df[col] = df[col].replace({"No internet service": "No", "No phone service": "No"})
    # Ensure SeniorCitizen is int
    if "SeniorCitizen" in df.columns:
        df["SeniorCitizen"] = df["SeniorCitizen"].astype("Int64").fillna(0).astype(int)
    # Drop rows with missing target
    if "Churn" in df.columns:
        df = df[~df["Churn"].isna()]
    return df

def split_xy(df: pd.DataFrame):
    y = df["Churn"].map({"Yes": 1, "No": 0})
    X = df.drop(columns=["Churn"])
    return X, y

def build_preprocessor(X: pd.DataFrame) -> ColumnTransformer:
    num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = X.select_dtypes(exclude=[np.number]).columns.tolist()
    num_pipe = Pipeline([("imputer", SimpleImputer(strategy="median"))])
    cat_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("ohe", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])
    pre = ColumnTransformer(
        transformers=[
            ("num", num_pipe, num_cols),
            ("cat", cat_pipe, cat_cols),
        ],
        remainder="drop"
    )
    return pre

def build_base_model(pre: ColumnTransformer) -> ImbPipeline:
    clf = RandomForestClassifier(
        n_estimators=300, n_jobs=-1, random_state=RANDOM_STATE
    )
    pipe = ImbPipeline([
        ("preprocess", pre),
        ("smote", SMOTE(random_state=RANDOM_STATE)),
        ("model", clf)
    ])
    return pipe

def tune(pipe: ImbPipeline, X, y) -> ImbPipeline:
    param_dist = {
        "model__n_estimators": randint(250, 700),
        "model__max_depth": randint(4, 32),
        "model__min_samples_split": randint(2, 12),
        "model__min_samples_leaf": randint(1, 8),
        "model__max_features": ["sqrt", "log2", None]
    }
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    search = RandomizedSearchCV(
        pipe, param_distributions=param_dist, n_iter=36,
        scoring="roc_auc", n_jobs=-1, cv=cv, random_state=RANDOM_STATE, verbose=1
    )
    search.fit(X, y)
    print("Best params:", search.best_params_)
    print("Best CV ROC AUC:", round(search.best_score_, 4))
    return search.best_estimator_

def evaluate(model: ImbPipeline, X_test, y_test):
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]
    print("\nHoldout Evaluation")
    print("-------------------")
    print("Accuracy:", round(accuracy_score(y_test, y_pred), 4))
    print("Recall:", round(recall_score(y_test, y_pred), 4))
    print("F1     :", round(f1_score(y_test, y_pred), 4))
    print("ROC AUC:", round(roc_auc_score(y_test, y_proba), 4))
    print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))
    print("\nClassification Report:\n", classification_report(y_test, y_pred, target_names=["No Churn", "Churn"]))

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", type=str, default="WA_Fn-UseC_-Telco-Customer-Churn (1).csv",
                        help="Path to Telco churn CSV")
    parser.add_argument("--out", type=str, default="customer_churn_pipeline.pkl",
                        help="Output path for saved pipeline")
    args = parser.parse_args()

    df = load_and_clean(args.csv)
    X, y = split_xy(df)
    pre = build_preprocessor(X)
    base = build_base_model(pre)

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    best = tune(base, X_train, y_train)
    evaluate(best, X_test, y_test)

    import joblib
    joblib.dump(best, args.out)
    print(f"\n✅ Saved full pipeline (preprocess + SMOTE + model) to '{args.out}'")

if __name__ == "__main__":
    main()
