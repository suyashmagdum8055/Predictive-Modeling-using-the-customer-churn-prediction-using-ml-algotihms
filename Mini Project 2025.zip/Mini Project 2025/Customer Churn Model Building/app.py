import streamlit as st
import pandas as pd
import joblib

st.set_page_config(page_title="Customer Churn Prediction", layout="wide")
st.title("📊 Customer Churn Prediction – A1 Pipeline")
st.write("Trained RandomForest pipeline with preprocessing + SMOTE baked in.")

@st.cache_resource
def load_pipeline(path: str):
    return joblib.load(path)

model_path = st.sidebar.text_input("Model file path", value="customer_churn_pipeline.pkl")
try:
    pipe = load_pipeline(model_path)
    st.sidebar.success("Model loaded ✔")
except Exception as e:
    st.sidebar.error(f"Failed to load model: {e}")
    st.stop()

mode = st.sidebar.radio("Mode", ["Single Prediction", "Batch Prediction"])

feature_order = [
    "gender","SeniorCitizen","Partner","Dependents","tenure","PhoneService",
    "MultipleLines","InternetService","OnlineSecurity","OnlineBackup",
    "DeviceProtection","TechSupport","StreamingTV","StreamingMovies",
    "Contract","PaperlessBilling","PaymentMethod","MonthlyCharges","TotalCharges"
]

def single_form():
    st.subheader("🔹 Single Customer Input")
    col1, col2, col3 = st.columns(3)
    with col1:
        gender = st.selectbox("gender", ["Male","Female"])
        senior = st.selectbox("SeniorCitizen", [0,1])
        partner = st.selectbox("Partner", ["Yes","No"])
        dependents = st.selectbox("Dependents", ["Yes","No"])
        tenure = st.number_input("tenure (months)", min_value=0, max_value=120, value=1)
        phone = st.selectbox("PhoneService", ["Yes","No"])
    with col2:
        multiple = st.selectbox("MultipleLines", ["Yes","No","No phone service"])
        internet = st.selectbox("InternetService", ["DSL","Fiber optic","No"])
        online_sec = st.selectbox("OnlineSecurity", ["Yes","No","No internet service"])
        online_bak = st.selectbox("OnlineBackup", ["Yes","No","No internet service"])
        device_prot = st.selectbox("DeviceProtection", ["Yes","No","No internet service"])
        tech_supp = st.selectbox("TechSupport", ["Yes","No","No internet service"])
    with col3:
        stream_tv = st.selectbox("StreamingTV", ["Yes","No","No internet service"])
        stream_mov = st.selectbox("StreamingMovies", ["Yes","No","No internet service"])
        contract = st.selectbox("Contract", ["Month-to-month","One year","Two year"])
        paperless = st.selectbox("PaperlessBilling", ["Yes","No"])
        payment = st.selectbox("PaymentMethod", [
            "Electronic check","Mailed check","Bank transfer (automatic)","Credit card (automatic)"
        ])
        monthly = st.number_input("MonthlyCharges", min_value=0.0, value=50.0)
        total = st.number_input("TotalCharges", min_value=0.0, value=500.0)
    
    if st.button("🔍 Predict"):
        row = pd.DataFrame([[
            gender, senior, partner, dependents, tenure, phone, multiple, internet,
            online_sec, online_bak, device_prot, tech_supp, stream_tv, stream_mov,
            contract, paperless, payment, monthly, total
        ]], columns=feature_order)
        try:
            prob = pipe.predict_proba(row)[:,1][0]
            pred = pipe.predict(row)[0]
            label = "Churn" if pred == 1 else "No Churn"
            st.success(f"✅ Prediction: **{label}** | Probability: **{prob:.2f}**")
            st.json(row.iloc[0].to_dict())
        except Exception as e:
            st.error(f"Prediction failed: {e}")

def batch_panel():
    st.subheader("🔹 Batch Prediction (CSV Upload)")
    st.caption("CSV must include these columns (case sensitive):")
    st.code(", ".join(feature_order))
    file = st.file_uploader("Upload CSV", type=["csv"])
    if file is not None:
        try:
            df = pd.read_csv(file)
            probs = pipe.predict_proba(df)[:,1]
            preds = pipe.predict(df)
            out = df.copy()
            out["Prediction"] = ["Churn" if p==1 else "No Churn" for p in preds]
            out["Probability"] = probs.round(3)
            st.dataframe(out.head(20))
            csv = out.to_csv(index=False).encode("utf-8")
            st.download_button("📥 Download Predictions", data=csv, file_name="churn_predictions.csv", mime="text/csv")
        except Exception as e:
            st.error(f"Batch prediction failed: {e}")

if mode == "Single Prediction":
    single_form()
else:
    batch_panel()
