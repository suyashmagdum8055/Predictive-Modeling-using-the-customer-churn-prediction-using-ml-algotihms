import streamlit as st
import pandas as pd
import numpy as np
import pickle

# ==============================
# Load Dataset & Model
# ==============================
@st.cache_data
def load_data():
    df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn (1).csv")
    return df

@st.cache_resource
def load_model():
    with open("customer_churn_model.pkl", "rb") as file:
        model = pickle.load(file)
    return model

# ==============================
# Input Builder Class
# ==============================
class InputBuilder:
    def __init__(self, df):
        self.df = df
        self.schema = self._build_schema()

    def _build_schema(self):
        schema = {}
        for col in self.df.columns:
            if self.df[col].dtype == "object":
                schema[col] = {
                    "type": "categorical",
                    "options": self.df[col].dropna().unique().tolist()
                }
            else:
                schema[col] = {
                    "type": "numeric",
                    "min": float(self.df[col].min()),
                    "max": float(self.df[col].max())
                }
        return schema

    def render_form(self):
        data = {}
        for key, meta in self.schema.items():
            if key in ["customerID", "Churn"]:  # skip target & ID
                continue

            if meta["type"] == "categorical":
                data[key] = st.selectbox(f"{key}", meta["options"])
            else:
                data[key] = st.number_input(
                    f"{key}",
                    min_value=float(meta["min"]),
                    max_value=float(meta["max"]),
                    value=float(meta["min"])
                )
        return data

# ==============================
# Main App Class
# ==============================
class ChurnApp:
    def __init__(self):
        self.df = load_data()
        self.model = load_model()
        self.input_builder = InputBuilder(self.df)

    def run(self):
        st.title("📊 Customer Churn Prediction App")

        st.write("Fill in the customer details below to check if they are likely to churn.")

        with st.form("churn_form"):
            form_data = self.input_builder.render_form()
            submitted = st.form_submit_button("Predict Churn")

        if submitted:
            input_df = pd.DataFrame([form_data])

            try:
                prediction = self.model.predict(input_df)[0]
                prob = self.model.predict_proba(input_df)[0][1]

                if prediction == 1:
                    st.error(f"⚠️ Customer is likely to **Churn** (Probability: {prob:.2f})")
                else:
                    st.success(f"✅ Customer is **Not Churning** (Probability: {prob:.2f})")
            except Exception as e:
                st.error(f"Model Prediction Error: {e}")

# ==============================
# Run App
# ==============================
if __name__ == "__main__":
    app = ChurnApp()
    app.run()
