import pandas as pd
import pickle

# Load model & encoders
with open('../models/model.pkl', 'rb') as f:
    model = pickle.load(f)
with open('../models/encoders.pkl', 'rb') as f:
    encoders = pickle.load(f)

# Example customer data
customer_data = {
    "gender": "Female",
    "SeniorCitizen": 0,
    "Partner": "Yes",
    "Dependents": "No",
    "tenure": 1,
    "PhoneService": "No",
    "MultipleLines": "No phone service",
    "InternetService": "DSL",
    "OnlineSecurity": "No",
    "OnlineBackup": "Yes",
    "DeviceProtection": "No",
    "TechSupport": "No",
    "StreamingTV": "No",
    "StreamingMovies": "No",
    "Contract": "Month-to-month",
    "PaperlessBilling": "Yes",
    "PaymentMethod": "Electronic check",
    "MonthlyCharges": 29.85,
    "TotalCharges": 29.85
}

input_df = pd.DataFrame([customer_data])

# Encode categorical features
for column, encoder in encoders.items():
    if column in input_df.columns:
        input_df[column] = encoder.transform(input_df[column])

# Predict
prediction = model.predict(input_df)
probability = model.predict_proba(input_df)[:,1]

print("Prediction:", "Churn" if prediction[0] == 1 else "No Churn")
print("Churn Probability:", probability[0])
