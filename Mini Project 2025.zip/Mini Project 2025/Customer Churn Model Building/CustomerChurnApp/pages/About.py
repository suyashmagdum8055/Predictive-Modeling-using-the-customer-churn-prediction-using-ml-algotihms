import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# -------------------------------
# Page Configuration
# -------------------------------
st.set_page_config(page_title="About Project", page_icon="ℹ️", layout="wide")

# -------------------------------
# Custom CSS for a refreshed look
# -------------------------------
st.markdown("""
    <style>
        /* General page styling */
        .stApp {
            background: linear-gradient(135deg, #e3f2fd, #bbdefb);
            color: #1a237e;
            font-family: 'Poppins', sans-serif;
        }

        /* Title styling */
        .title {
            text-align: center;
            color: #0d47a1;
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 2rem;
            letter-spacing: 1px;
        }
        
        /* Subheader styling */
        .subheader {
            color: #1565c0;
            font-size: 1.8rem;
            font-weight: 600;
            margin-top: 2.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #e0e0e0;
        }

        /* Section containers */
        .section-container {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            transition: transform 0.3s ease-in-out;
        }
        .section-container:hover {
            transform: translateY(-8px);
        }
        
        /* List styling with custom markers */
        .section-container ul {
            list-style-type: none;
            padding-left: 0;
        }
        .section-container li {
            position: relative;
            padding-left: 25px;
            margin-bottom: 12px;
            line-height: 1.6;
        }
        .section-container li::before {
            content: '👉';
            position: absolute;
            left: 0;
            font-size: 1.2em;
            color: #0d47a1;
        }
        
        /* Insights styling */
        .insights-box {
            background-color: #e8f5e9;
            color: #1b5e20;
            border-left: 6px solid #43a047;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }

    </style>
""", unsafe_allow_html=True)

# -------------------------------
# Data Loading & Caching
# -------------------------------
@st.cache_data
def load_data():
    """
    Loads the dataset from a CSV file.
    NOTE: The path below is hardcoded. For a production app,
    st.file_uploader would be a better choice.
    """
    try:
        df = pd.read_csv("C:/Users/Public/Mini Project 2025/Customer Churn Model Building/CustomerChurnApp/data/WA_Fn-UseC_-Telco-Customer-Churn (1).csv")
        return df
    except FileNotFoundError:
        st.error("❌ Dataset not found. Please check the file path.")
        st.stop()

df = load_data()

# -------------------------------
# Main Content
# -------------------------------
st.markdown("<h1 class='title'>ℹ️ About the Project</h1>", unsafe_allow_html=True)

# Project Overview Section
with st.container():
    st.markdown("<div class='section-container'>", unsafe_allow_html=True)
    st.markdown("<h3 class='subheader'>Project Overview</h3>", unsafe_allow_html=True)
    st.markdown(
        """
        This project leverages machine learning to predict customer churn for a telecom company.
        By analyzing a comprehensive dataset with customer behavior and service information,
        the predictive model can identify customers at a high risk of discontinuing their service.
        """
    )
    st.markdown("</div>", unsafe_allow_html=True)

# Motivation and Importance
with st.container():
    st.markdown("<div class='section-container'>", unsafe_allow_html=True)
    st.markdown("<h3 class='subheader'>Motivation & Business Impact</h3>", unsafe_allow_html=True)
    st.markdown(
        """
        <ul>
            <li>Customer churn is a significant business challenge, as losing customers directly impacts revenue and market share.</li>
            <li>It is often more expensive to acquire a new customer than to retain an existing one.</li>
            <li>Predictive churn models provide actionable insights, allowing companies to proactively engage with at-risk customers and improve retention strategies.</li>
        </ul>
        """
    , unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

# Tools and Technologies
with st.container():
    st.markdown("<div class='section-container'>", unsafe_allow_html=True)
    st.markdown("<h3 class='subheader'>Tools & Technologies</h3>", unsafe_allow_html=True)
    st.markdown(
        """
        This project was developed using a modern data science and web development stack:
        <br><br>
        **Primary Tools:** Python, Scikit-learn, Streamlit, Pandas, Matplotlib, Seaborn
        <br>
        **Models:** The model was built using robust classification algorithms, including **Random Forest** and **XGBoost**.
        """,
        unsafe_allow_html=True
    )
    st.markdown("</div>", unsafe_allow_html=True)

# -------------------------------
# Key Data Insights
# -------------------------------
st.markdown("<h3 class='subheader'>Key Data Insights</h3>", unsafe_allow_html=True)

col1, col2 = st.columns(2)

with col1:
    st.markdown("<h4>Churn Distribution</h4>", unsafe_allow_html=True)
    fig1, ax1 = plt.subplots(figsize=(4, 3))
    sns.countplot(data=df, x="Churn", palette=["#ff6b6b", "#4ecdc4"], ax=ax1)
    ax1.set_title("Customer Churn Distribution", color="#0d47a1")
    ax1.set_xlabel("Churn Status", color="#1a237e")
    ax1.set_ylabel("Number of Customers", color="#1a237e")
    ax1.tick_params(colors='#37474f')
    plt.tight_layout()
    st.pyplot(fig1)

with col2:
    st.markdown("<h4>Contract Type vs Churn</h4>", unsafe_allow_html=True)
    fig2, ax2 = plt.subplots(figsize=(5, 3))
    sns.countplot(data=df, x="Contract", hue="Churn", palette=["#ff6b6b", "#4ecdc4"], ax=ax2)
    plt.xticks(rotation=20)
    ax2.set_title("Churn by Contract Type", color="#0d47a1")
    ax2.set_xlabel("Contract Type", color="#1a237e")
    ax2.set_ylabel("Number of Customers", color="#1a237e")
    ax2.tick_params(colors='#37474f')
    plt.tight_layout()
    st.pyplot(fig2)

st.markdown("<h4>Monthly Charges Distribution</h4>", unsafe_allow_html=True)
fig3, ax3 = plt.subplots(figsize=(6, 3))
sns.histplot(df["MonthlyCharges"], bins=30, kde=True, color="#00796b", ax=ax3)
ax3.set_title("Monthly Charges Distribution", color="#0d47a1")
ax3.set_xlabel("Monthly Charges", color="#1a237e")
ax3.set_ylabel("Count", color="#1a237e")
ax3.tick_params(colors='#37474f')
plt.tight_layout()
st.pyplot(fig3)

# Summary of Insights
st.markdown(
    """
    <div class="insights-box">
        <h4 style="color: #1b5e20;">Key Takeaways:</h4>
        <ul>
            <li>Customers on **month-to-month contracts** have a significantly higher churn rate.</li>
            <li>There is a clear relationship between **higher monthly charges** and an increased likelihood of churn.</li>
            <li>Targeted retention campaigns should focus on these at-risk customer segments.</li>
        </ul>
    </div>
    """, unsafe_allow_html=True
)
