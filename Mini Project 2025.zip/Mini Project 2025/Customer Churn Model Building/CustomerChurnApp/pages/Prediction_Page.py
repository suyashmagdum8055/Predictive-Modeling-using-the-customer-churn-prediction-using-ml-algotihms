import streamlit as st
import pandas as pd
import pickle
import requests
import json
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.preprocessing import LabelEncoder
import numpy as np
from streamlit_lottie import st_lottie

# -------------------------------
# Load Lottie Animation Function
# -------------------------------
@st.cache_data
def load_lottieurl(url: str):
    """Loads a Lottie animation from a URL."""
    r = requests.get(url)
    if r.status_code != 200:
        return None
    return r.json()

# -------------------------------
# Load Model Function
# -------------------------------
@st.cache_resource
def load_model(pkl_path: str):
    """Loads the model and encoders from a pickle file."""
    try:
        with open(pkl_path, "rb") as f:
            obj = pickle.load(f)
        # If saved as dict {"model": clf, "encoders": {...}}, return the model and encoders
        if isinstance(obj, dict):
            model = obj.get("model", None)
            encoders = obj.get("encoders", None)
            return model, encoders
        # Otherwise, assume the pickle file is just the model
        return obj, None
    except FileNotFoundError:
        st.error(f"❌ File not found: {pkl_path}")
        st.stop()
    except Exception as e:
        st.error(f"❌ Error loading model: {e}")
        st.stop()

# 👉 Change this path to your actual file location
MODEL_PATH = r"C:\Users\Public\Mini Project 2025\Customer Churn Model Building\CustomerChurnApp\models\customer_churn_model.pkl"
model, encoders = load_model(MODEL_PATH)

# -------------------------------
# Preprocessing Function
# -------------------------------
def preprocess_data(df, encoders):
    """Preprocesses the dataframe for prediction using the loaded encoders."""
    # Drop ID column if exists
    if "customerID" in df.columns:
        df = df.drop(columns=["customerID"])

    # Convert TotalCharges to numeric
    if "TotalCharges" in df.columns:
        df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
        df.dropna(inplace=True)

    # Ensure Churn column exists
    if "Churn" not in df.columns:
        st.warning("⚠️ The uploaded file must contain a 'Churn' column for evaluation.")
        return None, None

    # Separate features and target
    X = df.drop("Churn", axis=1)
    y = df["Churn"]

    # Drop unwanted columns if present
    drop_cols = ["Predicted_Churn"]
    for col in drop_cols:
        if col in X.columns:
            X = X.drop(columns=[col])

    # Categorical encoding using provided encoders if available, otherwise fit and transform
    categorical_cols = [
        "gender", "SeniorCitizen", "Partner", "Dependents", "PhoneService",
        "MultipleLines", "InternetService", "OnlineSecurity", "OnlineBackup",
        "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies",
        "Contract", "PaperlessBilling", "PaymentMethod",
    ]
    for col in categorical_cols:
        if col in X.columns:
            if encoders and col in encoders:
                le = encoders[col]
                # Check for new categories not seen during training
                try:
                    X[col] = le.transform(X[col].astype(str))
                except ValueError as e:
                    st.error(f"❌ Value Error in column '{col}': {e}")
                    st.stop()
            else:
                # If no encoders provided, fit new ones
                le = LabelEncoder()
                X[col] = le.fit_transform(X[col].astype(str))

    # Encode target
    y = y.apply(lambda x: 1 if x == "Yes" else 0)

    return X, y

# -------------------------------
# Page Config & Custom CSS
# -------------------------------
st.set_page_config(page_title="📊 Customer Churn Prediction", page_icon="📈", layout="wide")

# Inject custom CSS for styling
st.markdown("""
    <style>
        body { background-color: #f8f9fa; }
        .title { text-align: center; color: #2c3e50; font-size: 40px; font-weight: bold; animation: fadeInDown 1s ease; }
        .subtitle { text-align: center; font-size: 18px; color: #555; margin-bottom: 30px; }
        .stButton>button {
            background: linear-gradient(135deg, #4CAF50, #2ecc71);
            color: white; font-weight: bold; border-radius: 12px;
            padding: 10px 20px; transition: 0.3s;
        }
        .stButton>button:hover {
            background: linear-gradient(135deg, #2ecc71, #27ae60);
            transform: scale(1.05);
        }
        .result-box {
            padding: 20px; border-radius: 15px; background: white;
            box-shadow: 0px 4px 20px rgba(0,0,0,0.1);
            margin-bottom: 20px; animation: fadeInUp 1s ease;
        }
        @keyframes fadeInDown {
            from {opacity: 0; transform: translateY(-20px);}
            to {opacity: 1; transform: translateY(0);}
        }
        @keyframes fadeInUp {
            from {opacity: 0; transform: translateY(20px);}
            to {opacity: 1; transform: translateY(0);}
        }
    </style>
""", unsafe_allow_html=True)

# Load Lottie animation
lottie_json = load_lottieurl("https://assets9.lottiefiles.com/packages/lf20_49rdyysj.json")

# -------------------------------
# UI Layout
# -------------------------------
st.markdown("<div class='title'>📊 Customer Churn Prediction</div>", unsafe_allow_html=True)
st.markdown("<div class='subtitle'>Upload a CSV file to predict churn using our trained ML model</div>", unsafe_allow_html=True)

if lottie_json:
    st_lottie(lottie_json, height=200, key="data_animation")

uploaded_file = st.file_uploader("📂 Upload your CSV file", type=["csv"])

if uploaded_file is not None:
    data = pd.read_csv(uploaded_file)

    st.markdown("<div class='result-box'><h4>🔍 Uploaded Data Preview</h4></div>", unsafe_allow_html=True)
    st.dataframe(data.head(), use_container_width=True)

    # Preprocess data
    X, y_true = preprocess_data(data.copy(), encoders)

    if X is not None:
        # Predict
        try:
            y_pred = model.predict(X)
        except Exception as e:
            st.error(f"❌ Prediction failed: {e}")
            st.stop()

        # Show results
        st.markdown("<div class='result-box'><h4>✅ Prediction Results</h4></div>", unsafe_allow_html=True)
        data_with_predictions = data.copy()
        # Align data with predictions after dropping NaNs
        data_with_predictions = data_with_predictions.loc[X.index]
        data_with_predictions["Predicted_Churn"] = y_pred
        st.dataframe(data_with_predictions.head(), use_container_width=True)

        # Accuracy
        accuracy = accuracy_score(y_true, y_pred)
        st.markdown(f"<div class='result-box'><h3>🎯 Accuracy: {accuracy:.2f}</h3></div>", unsafe_allow_html=True)

        # Confusion Matrix
        st.markdown("<div class='result-box'><h4>📊 Confusion Matrix</h4></div>", unsafe_allow_html=True)
        st.write(confusion_matrix(y_true, y_pred))

        # Classification Report
        st.markdown("<div class='result-box'><h4>📑 Classification Report</h4></div>", unsafe_allow_html=True)
        st.text(classification_report(y_true, y_pred))

        # Download predictions
        csv = data_with_predictions.to_csv(index=False).encode("utf-8")
        st.download_button("📥 Download Predictions as CSV", csv, "predicted_churn.csv", "text/csv", key="download-csv")
