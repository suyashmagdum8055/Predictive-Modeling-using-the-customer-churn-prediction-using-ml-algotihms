import streamlit as st
from streamlit_lottie import st_lottie
import streamlit.components.v1 as components
import requests
from datetime import datetime
import pandas as pd
import joblib
from sklearn.preprocessing import LabelEncoder
import numpy as np

# ----------------------------------------------------
# Page Config
# ----------------------------------------------------
st.set_page_config(
    page_title="Customer Churn Prediction",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ----------------------------------------------------
# Helpers
# ----------------------------------------------------
@st.cache_data(show_spinner=False)
def load_lottieurl(url: str):
    """Loads a Lottie animation from a URL."""
    try:
        r = requests.get(url, timeout=7)
        if r.status_code != 200:
            return None
        return r.json()
    except Exception:
        return None

lottie_welcome = load_lottieurl("https://assets9.lottiefiles.com/packages/lf20_totrpclr.json")

# ----------------------------------------------------
# Model and Encoders Loading (from the previous app)
# ----------------------------------------------------
@st.cache_resource
def load_model_and_encoders():
    """
    Loads the pre-trained model and creates encoders.
    NOTE: The path below is hardcoded.
    """
    try:
        model = joblib.load("C:/Users/Public/Mini Project 2025/Customer Churn Model Building/CustomerChurnApp/models/customer_churn_model.pkl")
        
        # Manually define encoders based on common values in the dataset
        encoders = {}
        for col in ['gender', 'Partner', 'Dependents', 'PhoneService', 'MultipleLines',
                    'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
                    'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',
                    'PaperlessBilling', 'PaymentMethod', 'Churn']:
            le = LabelEncoder()
            if col == 'gender':
                le.fit(['Female', 'Male'])
            elif col in ['Partner', 'Dependents', 'PhoneService', 'PaperlessBilling', 'Churn']:
                le.fit(['No', 'Yes'])
            elif col == 'MultipleLines':
                le.fit(['No', 'Yes', 'No phone service'])
            elif col == 'InternetService':
                le.fit(['DSL', 'Fiber optic', 'No'])
            elif col in ['OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies']:
                le.fit(['No', 'Yes', 'No internet service'])
            elif col == 'Contract':
                le.fit(['Month-to-month', 'One year', 'Two year'])
            elif col == 'PaymentMethod':
                le.fit(['Electronic check', 'Mailed check', 'Bank transfer (automatic)', 'Credit card (automatic)'])
            encoders[col] = le
        return model, encoders
    except FileNotFoundError:
        st.error("❌ Model or encoder data not found. Please check the file path.")
        st.stop()

model, encoders = load_model_and_encoders()

# ----------------------------------------------------
# Global CSS + JS (wrapped correctly)
# ----------------------------------------------------
css_js = """
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&family=Poppins:wght@400;600;700;800&display=swap" rel="stylesheet">
<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">

<style>
  :root {
    --bg: #0b1220;
    --surface: rgba(255,255,255,0.06);
    --card: rgba(255,255,255,0.08);
    --text: #e9eef6;
    --muted: #9fb0c3;
    --brand: #7c5cff;
    --brand-2: #00d4ff;
    --accent: #ff7a59;
    --glow: 0 10px 30px rgba(124,92,255,.35);
  }

  html, body, [class^="css"] {
    font-family: 'Inter', system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, 'Noto Sans', 'Helvetica Neue', Arial;
  }

  .stApp {
    color: var(--text);
    background: radial-gradient(1200px 800px at 10% -10%, #161a2a 0%, #0b1220 40%, #0b1220 100%);
  }

  /* Animated gradient blob background */
  .stApp::before {
    content: "";
    position: fixed; inset: -10% -10% auto -10%; height: 60vh; z-index: -1;
    filter: blur(60px); opacity: .55; pointer-events: none;
    background: radial-gradient(40% 60% at 10% 30%, rgba(124,92,255,.55), transparent 70%),
                radial-gradient(30% 40% at 90% 20%, rgba(0,212,255,.45), transparent 70%),
                radial-gradient(30% 40% at 50% 80%, rgba(255,122,89,.35), transparent 70%);
    animation: floaty 18s ease-in-out infinite alternate;
  }

  @keyframes floaty {
    to { transform: translateY(-20px) scale(1.03); }
  }

  /* Hero Title */
  .hero-title {
    font-family: 'Poppins', sans-serif;
    font-weight: 800;
    font-size: clamp(32px, 4.5vw, 64px);
    background: linear-gradient(90deg, var(--brand), var(--brand-2), var(--accent), var(--brand));
    background-size: 300% 100%;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: sheen 8s linear infinite;
    text-align: center;
  }

  @keyframes sheen {
    0% {background-position:0% 50%}
    50% {background-position:100% 50%}
    100% {background-position:0% 50%}
  }

  .hero-sub { text-align:center; color: var(--muted); font-size: 18px; margin-bottom: 1.25rem; }

  /* Glass cards */
  .glass-card {
    background: var(--card);
    border: 1px solid rgba(255,255,255,.08);
    box-shadow: var(--glow);
    border-radius: 18px;
    padding: 18px;
    transition: transform .25s ease, box-shadow .25s ease, border-color .25s ease;
  }
  .glass-card:hover { transform: translateY(-4px); box-shadow: 0 18px 50px rgba(124,92,255,.25); }
  
  /* Prediction Result Card */
  .prediction-card {
    background-color: #2c3e50;
    color: #ecf0f1;
    padding: 20px;
    border-radius: 10px;
    margin-top: 20px;
    text-align: center;
    border: 2px solid #3498db;
    animation: fadein 1s;
  }
  .prediction-card h4 {
      color: #3498db;
  }
  .prediction-card h3 {
      font-size: 2em;
  }
  .prediction-card.churn {
      border-color: #e74c3c;
      background-color: #c0392b;
  }
  .prediction-card.no-churn {
      border-color: #2ecc71;
      background-color: #27ae60;
  }
  
  @keyframes fadein {
      from { opacity: 0; }
      to { opacity: 1; }
  }


  /* Footer */
  .app-footer { text-align:center; color: var(--muted); margin-top: 24px; }
  .app-footer b { color: var(--brand-2); }

  #MainMenu { visibility: hidden; }
</style>

<script>
  // ripple effect on clicks
  document.addEventListener('click', function(e){
    const r = document.createElement('span');
    r.className = 'ripple';
    r.style.left = e.clientX + 'px';
    r.style.top = e.clientY + 'px';
    document.body.appendChild(r);
    setTimeout(()=>r.remove(), 600);
  });
</script>

<style>
  .ripple {
    position: fixed; width: 8px; height: 8px; pointer-events:none; border-radius:50%;
    transform: translate(-50%,-50%);
    background: radial-gradient(circle, rgba(255,255,255,.65) 0%, rgba(255,255,255,0) 70%);
    animation: rip .6s ease-out;
  }
  @keyframes rip {
    from {opacity:.9; transform:translate(-50%,-50%) scale(.6)}
    to {opacity:0; transform:translate(-50%,-50%) scale(8)}
  }
</style>
"""
components.html(css_js, height=0)

# ----------------------------------------------------
# Hero
# ----------------------------------------------------
st.markdown("<div class='hero-title'>Customer Churn Prediction Studio</div>", unsafe_allow_html=True)
st.markdown("<div class='hero-sub'>Dashing, delightful & data-driven — ML-powered retention for telecoms.</div>", unsafe_allow_html=True)

# Animation + About
c1, c2 = st.columns([1, 1])
with c1:
    if lottie_welcome:
        st_lottie(lottie_welcome, height=300, key="welcome")
    else:
        st.info("Animation couldn't load — you're still awesome ✨")
with c2:
    st.markdown(
        """
        <div class="glass-card">
            <h4>💡 Why this project?</h4>
            <p>Churn erodes revenue. Predicting it early lets you act — offers, support, outreach — before a customer leaves.</p>
            <p>This app demonstrates AI/ML powered churn prediction with a beautiful Streamlit UI.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

# ----------------------------------------------------
# Interactive Prediction Form
# ----------------------------------------------------
st.markdown("---")
st.markdown("<h2 style='text-align: center; color: var(--text);'>Try the Churn Predictor</h2>", unsafe_allow_html=True)

with st.expander("Enter Customer Details for Prediction", expanded=False):
    with st.form(key='churn_form'):
        # Create columns for a cleaner layout
        col_form1, col_form2, col_form3 = st.columns(3)

        with col_form1:
            st.markdown("<h5 style='color: var(--brand);'>Demographics</h5>", unsafe_allow_html=True)
            gender = st.selectbox("Gender", options=encoders['gender'].classes_, key='gender_input')
            senior_citizen = st.checkbox("Senior Citizen", key='senior_citizen_input')
            partner = st.selectbox("Partner", options=encoders['Partner'].classes_, key='partner_input')
            dependents = st.selectbox("Dependents", options=encoders['Dependents'].classes_, key='dependents_input')
        
        with col_form2:
            st.markdown("<h5 style='color: var(--brand);'>Service Information</h5>", unsafe_allow_html=True)
            phone_service = st.selectbox("Phone Service", options=encoders['PhoneService'].classes_, key='phone_service_input')
            multiple_lines = st.selectbox("Multiple Lines", options=encoders['MultipleLines'].classes_, key='multiple_lines_input')
            internet_service = st.selectbox("Internet Service", options=encoders['InternetService'].classes_, key='internet_service_input')
            online_security = st.selectbox("Online Security", options=encoders['OnlineSecurity'].classes_, key='online_security_input')
            online_backup = st.selectbox("Online Backup", options=encoders['OnlineBackup'].classes_, key='online_backup_input')
            device_protection = st.selectbox("Device Protection", options=encoders['DeviceProtection'].classes_, key='device_protection_input')
            tech_support = st.selectbox("Tech Support", options=encoders['TechSupport'].classes_, key='tech_support_input')
            streaming_tv = st.selectbox("Streaming TV", options=encoders['StreamingTV'].classes_, key='streaming_tv_input')
            streaming_movies = st.selectbox("Streaming Movies", options=encoders['StreamingMovies'].classes_, key='streaming_movies_input')
        
        with col_form3:
            st.markdown("<h5 style='color: var(--brand);'>Billing Details</h5>", unsafe_allow_html=True)
            contract = st.selectbox("Contract", options=encoders['Contract'].classes_, key='contract_input')
            paperless_billing = st.selectbox("Paperless Billing", options=encoders['PaperlessBilling'].classes_, key='paperless_billing_input')
            payment_method = st.selectbox("Payment Method", options=encoders['PaymentMethod'].classes_, key='payment_method_input')
            monthly_charges = st.number_input("Monthly Charges", value=50.0, step=1.0, key='monthly_charges_input')
            total_charges = st.number_input("Total Charges", value=500.0, step=1.0, key='total_charges_input')
            tenure = st.slider("Tenure (months)", 1, 72, 12, key='tenure_input')

        st.markdown("---")
        submit_button = st.form_submit_button(label='Get Churn Prediction', use_container_width=True)

    if submit_button:
        # Create a DataFrame from the inputs
        input_data = {
            'gender': [gender],
            'SeniorCitizen': [1 if senior_citizen else 0],
            'Partner': [partner],
            'Dependents': [dependents],
            'tenure': [tenure],
            'PhoneService': [phone_service],
            'MultipleLines': [multiple_lines],
            'InternetService': [internet_service],
            'OnlineSecurity': [online_security],
            'OnlineBackup': [online_backup],
            'DeviceProtection': [device_protection],
            'TechSupport': [tech_support],
            'StreamingTV': [streaming_tv],
            'StreamingMovies': [streaming_movies],
            'Contract': [contract],
            'PaperlessBilling': [paperless_billing],
            'PaymentMethod': [payment_method],
            'MonthlyCharges': [monthly_charges],
            'TotalCharges': [total_charges]
        }
        input_df = pd.DataFrame(input_data)
        
        # Preprocess the DataFrame
        categorical_cols = [
            'gender', 'Partner', 'Dependents', 'PhoneService', 'MultipleLines',
            'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
            'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',
            'PaperlessBilling', 'PaymentMethod'
        ]
        
        for col in categorical_cols:
            input_df[col] = encoders[col].transform(input_df[col])

        # Make prediction
        features = [
            'gender', 'SeniorCitizen', 'Partner', 'Dependents', 'tenure', 'PhoneService',
            'MultipleLines', 'InternetService', 'OnlineSecurity', 'OnlineBackup',
            'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies',
            'Contract', 'PaperlessBilling', 'PaymentMethod', 'MonthlyCharges',
            'TotalCharges'
        ]
        
        try:
            prediction = model.predict(input_df[features])[0]
            prediction_proba = model.predict_proba(input_df[features])[0]
        except Exception as e:
            st.error(f"Prediction failed. Error: {e}")
            prediction = 0
            prediction_proba = [0.0, 0.0]

        # Display results in a stylish card
        is_churn = prediction == 1
        churn_status = "will churn" if is_churn else "will not churn"
        result_class = "churn" if is_churn else "no-churn"

        st.markdown(
            f"""
            <div class='prediction-card {result_class}'>
                <h4>Prediction Result</h4>
                <h3>This customer <br> <span style='font-weight: 800;'>{churn_status}</span></h3>
                <p>Confidence: <b>{prediction_proba[1]:.2%}</b></p>
            </div>
            """, unsafe_allow_html=True
        )

# ----------------------------------------------------
# Footer
# ----------------------------------------------------
st.markdown(
    """
    <div class='app-footer'>
      ✨ Built with <b>Streamlit</b> • Styled with <b>Glass + Gradients</b> <br/>
      Made with ❤️ by <b>Team Suyash</b>
    </div>
    """,
    unsafe_allow_html=True,
)
